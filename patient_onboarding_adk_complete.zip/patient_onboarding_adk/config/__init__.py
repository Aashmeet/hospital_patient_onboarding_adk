"""Hospital Onboarding configuration package."""

from .settings import settings

__all__ = ["settings"]
